-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 11:06 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wmsjp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` bigint(20) NOT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `address1` varchar(150) DEFAULT NULL,
  `address2` varchar(150) DEFAULT NULL,
  `region` varchar(50) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `phone_no` varchar(20) DEFAULT NULL,
  `primary_email` varchar(100) DEFAULT NULL,
  `secondary_email` varchar(100) DEFAULT NULL,
  `taxno` int(11) DEFAULT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_name`, `address1`, `address2`, `region`, `city`, `zipcode`, `country`, `phone_no`, `primary_email`, `secondary_email`, `taxno`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 'Itechvision', 'D-185,Industrial Area', '', 'Mohali', 'Mohali', 160074, 'India', '9876543210', 'itech@gmail.com', '', 980561111, 0, '2021-09-30 06:44:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jp_sessions`
--

CREATE TABLE `jp_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`module_id`, `slug`, `title`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(3, 'module', 'module', 0, '2021-08-12 23:04:10', '2021-08-13 13:52:41', '2021-08-16 13:06:13'),
(5, 'company', 'company', 0, '2021-08-12 23:15:25', NULL, '2021-08-13 13:52:47'),
(6, 'warehouse', 'warehouse', 0, '2021-08-15 22:34:42', NULL, NULL),
(7, 'shop', 'shop', 0, '2021-08-15 22:34:54', NULL, NULL),
(8, 'relation', 'relation', 0, '2021-08-16 01:32:32', NULL, NULL),
(9, 'role', 'role', 1, '2021-08-17 22:46:04', NULL, '2021-08-30 14:12:00'),
(10, 'product', 'product', 0, '2021-08-25 23:58:47', NULL, NULL),
(11, 'category', 'Category', 0, '2021-08-26 03:36:40', NULL, NULL),
(12, 'user', 'User', 0, '2021-08-29 22:33:54', NULL, NULL),
(13, 'user', 'User', 1, '2021-08-29 22:34:34', NULL, '2021-08-30 13:04:51'),
(14, 'user', 'User', 1, '2021-09-30 07:16:11', NULL, '2021-09-30 16:16:31');

-- --------------------------------------------------------

--
-- Table structure for table `module_permissions`
--

CREATE TABLE `module_permissions` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL DEFAULT 0,
  `c` tinyint(4) NOT NULL DEFAULT 0,
  `r` tinyint(4) NOT NULL DEFAULT 0,
  `u` tinyint(4) NOT NULL DEFAULT 0,
  `d` tinyint(4) NOT NULL DEFAULT 0,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `module_permissions`
--

INSERT INTO `module_permissions` (`id`, `role_id`, `module_id`, `user_id`, `c`, `r`, `u`, `d`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 1, 3, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:50', NULL, NULL),
(2, 1, 5, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:51', NULL, NULL),
(3, 1, 6, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:51', NULL, NULL),
(4, 1, 7, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:51', NULL, NULL),
(5, 1, 8, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:51', NULL, NULL),
(6, 1, 10, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:51', NULL, NULL),
(7, 1, 11, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:51', NULL, NULL),
(8, 1, 12, 0, 1, 1, 1, 1, 0, '2021-09-30 08:19:51', NULL, NULL),
(9, 2, 3, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL),
(10, 2, 5, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL),
(11, 2, 6, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL),
(12, 2, 7, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL),
(13, 2, 8, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL),
(14, 2, 10, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL),
(15, 2, 11, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL),
(16, 2, 12, 0, 0, 1, 0, 0, 0, '2021-09-30 08:24:18', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product1`
--

CREATE TABLE `product1` (
  `pro_id` int(11) NOT NULL,
  `pro_type_id` int(11) NOT NULL,
  `pro_cat_id` int(11) NOT NULL,
  `pro_sku` varchar(50) NOT NULL,
  `pro_barcode` varchar(20) NOT NULL,
  `pro_name` varchar(255) NOT NULL,
  `pro_price` float NOT NULL,
  `pro_img_id` int(11) DEFAULT NULL,
  `total_stock` int(11) DEFAULT NULL,
  `stock_manage` int(11) NOT NULL,
  `pro_parent_id` int(11) DEFAULT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NULL DEFAULT NULL,
  `delete_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product1`
--

INSERT INTO `product1` (`pro_id`, `pro_type_id`, `pro_cat_id`, `pro_sku`, `pro_barcode`, `pro_name`, `pro_price`, `pro_img_id`, `total_stock`, `stock_manage`, `pro_parent_id`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 2, 0, 'G0189', 'G012300', 'GUITAR-2', 500, 1, NULL, 0, NULL, 0, '2021-11-24 11:14:07', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `pro_cat_id` int(11) NOT NULL,
  `pro_cat_name` varchar(100) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `cat_parent_id` int(11) NOT NULL DEFAULT 0,
  `delete_flag` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NULL DEFAULT NULL,
  `delete_date` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`pro_cat_id`, `pro_cat_name`, `shop_id`, `cat_parent_id`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 'Toys', 1, 0, 0, '2021-09-30 08:36:59', NULL, NULL),
(2, 'Guitar', 1, 1, 0, '2021-09-30 08:40:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

CREATE TABLE `product_image` (
  `pro_img_id` int(11) NOT NULL,
  `pro_img_path` varchar(200) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `main_img` int(11) NOT NULL DEFAULT 0,
  `delete_flag` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NULL DEFAULT NULL,
  `delete_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_image`
--

INSERT INTO `product_image` (`pro_img_id`, `pro_img_path`, `shop_id`, `pro_id`, `main_img`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 'bandmember36.jpg', 1, 1, 0, 0, '2021-11-24 11:14:25', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_type`
--

CREATE TABLE `product_type` (
  `pro_type_id` int(11) NOT NULL,
  `pro_type_name` varchar(100) NOT NULL,
  `delete_flag` tinyint(4) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NULL DEFAULT NULL,
  `delete_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_type`
--

INSERT INTO `product_type` (`pro_type_id`, `pro_type_name`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 'Simple', 0, '2021-09-30 08:37:57', NULL, NULL),
(2, 'Variant', 0, '2021-09-30 08:37:34', NULL, NULL),
(3, 'Downloadable', 0, '2021-09-30 08:37:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_variant`
--

CREATE TABLE `product_variant` (
  `v_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(50) NOT NULL,
  `var_img_id` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `modify_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `relation`
--

CREATE TABLE `relation` (
  `relation_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `relation`
--

INSERT INTO `relation` (`relation_id`, `warehouse_id`, `shop_id`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 1, 1, 0, '2021-09-30 07:32:55', NULL, NULL),
(2, 2, 1, 0, '2021-09-30 08:17:37', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(30) DEFAULT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `role_name`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 'Administrator', 0, '2021-09-30 06:39:52', NULL, NULL),
(2, 'Manager', 0, '2021-09-30 08:20:21', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `shop_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT 0,
  `shop_name` varchar(150) DEFAULT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`shop_id`, `company_id`, `shop_name`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 1, 'ABC', 0, '2021-09-30 06:44:24', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_password` varchar(256) DEFAULT NULL,
  `role_id` int(11) DEFAULT 0,
  `company_id` int(11) DEFAULT 0,
  `user_status` int(11) DEFAULT 0,
  `user_phone` varchar(20) DEFAULT NULL,
  `user_image` varchar(150) DEFAULT NULL,
  `user_about` text DEFAULT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_password`, `role_id`, `company_id`, `user_status`, `user_phone`, `user_image`, `user_about`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 'Gurpreet', 'gurpreet@gmail.com', 'c465e6201050d604d031405e80978fa3', 1, 0, 1, '7009944646', 'happy-diwali-wishes-background-with-shiny-diya_1017-28458.jpg', 'I am Gurpreet', 0, '2021-09-30 06:12:30', '2021-09-30 08:09:26', '2021-09-30 08:09:26'),
(2, 'Arti', 'arti@gmail.com', 'aba41e947535e2687770e7fa7eb5980f', 2, 1, 1, '6789045321', NULL, NULL, 0, '2021-09-30 08:21:37', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `warehouse_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT 0,
  `warehouse_name` varchar(150) DEFAULT NULL,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`warehouse_id`, `company_id`, `warehouse_name`, `delete_flag`, `create_date`, `modify_date`, `delete_date`) VALUES
(1, 1, 'Mohali', 0, '2021-09-30 07:12:40', NULL, NULL),
(2, 1, 'Chandigarh', 0, '2021-09-30 07:26:22', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`),
  ADD KEY `company_name` (`company_name`);

--
-- Indexes for table `jp_sessions`
--
ALTER TABLE `jp_sessions`
  ADD KEY `sessions_timestamp` (`timestamp`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `module_permissions`
--
ALTER TABLE `module_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product1`
--
ALTER TABLE `product1`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`pro_cat_id`);

--
-- Indexes for table `product_image`
--
ALTER TABLE `product_image`
  ADD PRIMARY KEY (`pro_img_id`);

--
-- Indexes for table `product_type`
--
ALTER TABLE `product_type`
  ADD PRIMARY KEY (`pro_type_id`);

--
-- Indexes for table `product_variant`
--
ALTER TABLE `product_variant`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `relation`
--
ALTER TABLE `relation`
  ADD PRIMARY KEY (`relation_id`),
  ADD KEY `shop_id` (`shop_id`),
  ADD KEY `warehouse_id` (`warehouse_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `user_password` (`user_password`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`warehouse_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `module_permissions`
--
ALTER TABLE `module_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `product1`
--
ALTER TABLE `product1`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `pro_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product_image`
--
ALTER TABLE `product_image`
  MODIFY `pro_img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_type`
--
ALTER TABLE `product_type`
  MODIFY `pro_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product_variant`
--
ALTER TABLE `product_variant`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `relation`
--
ALTER TABLE `relation`
  MODIFY `relation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `shop`
--
ALTER TABLE `shop`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
  MODIFY `warehouse_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `relation`
--
ALTER TABLE `relation`
  ADD CONSTRAINT `relation_ibfk_1` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`shop_id`),
  ADD CONSTRAINT `relation_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouse` (`warehouse_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
