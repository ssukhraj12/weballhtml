<!DOCTYPE html>
<html lang="en">
<?php
include 'header.php'; ?>
<body>
<section id="schedule" class="bg-white">
    <div class="container">
        <div class="row pt-3">
            <h2>Schedule List</h2>
            <form class="form-horizontal col-9">
                <div class="row mb-2">
                    <label for="date_from" class="col-1 col-form-label">From</label>
                    <div class="col-3">
                        <input type="date" class="form-control form-control-sm" id="date_from" placeholder="date">
                    </div>
                    <label for="date_to" class="col-1 col-form-label">to</label>
                    <div class="col-3">
                        <input type="date" class="form-control form-control-sm" id="date_to" placeholder="date">
                    </div>
                </div>
                <div class="row mb-2">
                    <label for="developer" class="form-label col-1">Developer</label>
                    <div class="col-5">
                        <select id="developer" class="form-select form-select-sm">
                            <option>Choose Developer</option>
                            <option>Amarjeet</option>
                            <option>Jaspreet</option>
                            <option>Bharti</option>
                            <option>Sunil</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
            <div class="alert-success small">
                Developer 1 Schedule from 01/04/2022 to 30/04/2022
            </div>


        </div>
    </div>
</section>
<section class="container bg-white">
    <table id="HourlysalesSummary" class="table"></table>
</section>
<script>
    $(document).ready(function () {

        var tableData = [
            {
                "Date / Time <br> April": "C001",
                "9am": "1",
                "10am": "1",
                "11am": "1",
                "12am": "1",
                "Break": "",
                "2pm": "1",
                "3pm": "1",
                "4pm": "1",
                "5pm": "1",
                "Total": "8"

            },
            {
                "Date / Time <br> April": "C002",
                "9am": "1",
                "10am": "1",
                "11am": "1",
                "12am": "1",
                "Break": "",
                "2pm": "1",
                "3pm": "1",
                "4pm": "1",
                "5pm": "1",
                "Total": "8"

            },
            {
                "Date / Time <br> April": "C003",
                "9am": "1",
                "10am": "1",
                "11am": "1",
                "12am": "1",
                "Break": "",
                "2pm": "1",
                "3pm": "1",
                "4pm": "1",
                "5pm": "1",
                "Total": "8"

            },
            {
                "Date / Time <br> April": "C004",
                "9am": "1",
                "10am": "1",
                "11am": "1",
                "12am": "1",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "4"

            },
            {
                "Date / Time <br> April": "C005",
                "9am": "",
                "10am": "",
                "11am": "",
                "12am": "",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "0"

            },
            {
                "Date / Time <br> April": "C006",
                "9am": "",
                "10am": "",
                "11am": "",
                "12am": "",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "0"


            },
            {
                "Date / Time <br> April": "C007",
                "9am": "",
                "10am": "",
                "11am": "",
                "12am": "",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "0"


            },
            {
                "Date / Time <br> April": "C008",
                "9am": "",
                "10am": "",
                "11am": "",
                "12am": "",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "0"


            },
            {
                "Date / Time <br> April": "C009",
                "9am": "",
                "10am": "",
                "11am": "",
                "12am": "",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "0"


            },
            {
                "Date / Time <br> April": "C010",
                "9am": "",
                "10am": "",
                "11am": "",
                "12am": "",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "0"


            },
            {
                "Date / Time <br> April": "C011",
                "9am": "",
                "10am": "",
                "11am": "",
                "12am": "",
                "Break": "",
                "2pm": "",
                "3pm": "",
                "4pm": "",
                "5pm": "",
                "Total": "0"


            }

        ]


        function addTable(tableValue) {
            var col = Object.keys(tableValue[0]);
            var countNum = col.filter(i => !isNaN(i)).length;
            var num = col.splice(0, countNum);
            col = col.concat(num);
            var table = document.createElement("table");
            var tr = table.insertRow(-1); // TABLE ROW.
            for (var i = 0; i < col.length; i++) {
                var th = document.createElement("th"); // TABLE HEADER.
                th.innerHTML = col[i];
                tr.appendChild(th);
                tr.classList.add("text-center");
                tr.classList.add("head")
            }
            for (var i = 0; i < tableValue.length; i++) {
                tr = table.insertRow(-1);
                for (var j = 0; j < col.length; j++) {
                    var tabCell = tr.insertCell(-1);
                    var tabledata = tableValue[i][col[j]];
                    if (tabledata && !isNaN(tabledata)) {
                        tabledata = parseInt(tabledata).toLocaleString('en-in')
                    }
                    if (tableData[i]['Total'] === tableData[i][col[j]]) {
                        //to make this cell editable
                        tabCell.setAttribute('contenteditable', true); // <--- ADDING HERE
                        tabCell.innerHTML = tabledata;
                    } else {
                        span = document.createElement("span");
                        span.innerHTML = tabledata;
                        tabCell.appendChild(span)
                    }
                    if (j > 1)

                        tabCell.classList.add("text-center");

                }
            }
            var divContainer = document.getElementById("HourlysalesSummary");
            divContainer.innerHTML = "";
            divContainer.appendChild(table);
            table.classList.add("table");
            table.classList.add("table-bordered");
            table.classList.add("table-hover");

        }

        addTable(tableData);

    });
</script>

<?php
include 'footer.php'; ?>
</body>
</html>

