<!DOCTYPE html>
<html lang="en">
<?php include 'header.php';?>
<body>
<section class="main bg-white min-vh-100">
    <div class="container-fluid">
        <div class="row pt-3 text-center align-items-end border border-bottom">
                <div class="col-1">
                    <a class="p-2 bg-light-lighten form-control" type="date" href="#">
                        <div class="calendar-month fw-bold">Apr</div>
                        <div class="calendar-date fw-bolder fs-3">01</div>
                        <div class="calendar-day">Fri</div>
                    </a>
                </div>
                <div class="col-1">
                    <a class="p-2 bg-light-lighten form-control" type="date" href="#">
                        <div class="calendar-month fw-bold">Apr</div>
                        <div class="calendar-date fw-bolder fs-3">30</div>
                        <div class="calendar-day">Sat</div>
                    </a>
                </div>
            <div class="col-sm-10">
                <div class="row">
                    <div class="col-12 fw-bold fs-3 bg-success-lighten">2022 April</div>
                    <div class="col-12">
                        <div class="weeks">
                            <div class="w13">
                                Week 13
                                <div class="days">
                                    <span class="day d_1">01</span>
                                    <span class="day d_2">02</span>
                                    <span class="day d_3">03</span>
                                </div>
                            </div>
                            <div class="w14">
                                Week 14
                                <div class="days">
                                    <div class="day d_4">04</div>
                                    <div class="day d_5">05</div>
                                    <div class="day d_6">06</div>
                                    <div class="day d_7">07</div>
                                    <div class="day d_8">08</div>
                                    <div class="day d_9">09</div>
                                    <div class="day d_10">10</div>
                                </div>

                            </div>
                            <div class="w15">
                                Week 15
                                <div class="days">
                                    <div class="day d_4">11</div>
                                    <div class="day d_5">12</div>
                                    <div class="day d_6">13</div>
                                    <div class="day d_7">14</div>
                                    <div class="day d_8">15</div>
                                    <div class="day d_9">16</div>
                                    <div class="day d_10">17</div>
                                </div>
                            </div>
                            <div class="w16">
                                Week 16
                                <div class="days">
                                    <div class="day d_4">18</div>
                                    <div class="day d_5">19</div>
                                    <div class="day d_6">20</div>
                                    <div class="day d_7">21</div>
                                    <div class="day d_8">22</div>
                                    <div class="day d_9">23</div>
                                    <div class="day d_10">24</div>
                                </div>
                            </div>
                            <div class="w17">
                                Week 17
                                <div class="days">
                                    <div class="day d_25">25</div>
                                    <div class="day d_26">26</div>
                                    <div class="day d_27">27</div>
                                    <div class="day d_28">28</div>
                                    <div class="day d_29">29</div>
                                    <div class="day d_30">30</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row text-center align-items-center border-bottom">
            <div class="col-2">
                <div class="details">
                    <div class="Branch fw-bold">Amarjeet
                        <span class="badge badge-info-lighten">22h</span>
                        <span class="badge badge-danger-lighten">140h</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-10">
                <div class="row">
                    <div class="col-12">
                        <div class="weeks">
                            <div class="w13">
                                <div class="days">
                                    <div class="day d_1">01</div>
                                    <div class="day d_2">01</div>
                                    <div class="day d_3">01</div>
                                </div>
                            </div>
                            <div class="w14">
                                <div class="days">
                                    <div class="day d_4">01</div>
                                    <div class="day d_5">01</div>
                                    <div class="day d_6">01</div>
                                    <div class="day d_7">01</div>
                                    <div class="day d_8">01</div>
                                    <div class="day d_9">01</div>
                                    <div class="day d_10">01</div>
                                </div>

                            </div>
                            <div class="w15">
                                <div class="days">
                                    <div class="day d_4">00</div>
                                    <div class="day d_5">00</div>
                                    <div class="day d_6">00</div>
                                    <div class="day d_7">00</div>
                                    <div class="day d_8">00</div>
                                    <div class="day d_9">00</div>
                                    <div class="day d_10">00</div>
                                </div>
                            </div>
                            <div class="w16">
                                <div class="days">
                                    <div class="day d_4">00</div>
                                    <div class="day d_5">00</div>
                                    <div class="day d_6">00</div>
                                    <div class="day d_7">00</div>
                                    <div class="day d_8">00</div>
                                    <div class="day d_9">00</div>
                                    <div class="day d_10">00</div>
                                </div>
                            </div>
                            <div class="w17">
                                <div class="days">
                                    <div class="day d_25">00</div>
                                    <div class="day d_26">00</div>
                                    <div class="day d_27">00</div>
                                    <div class="day d_28">00</div>
                                    <div class="day d_29">00</div>
                                    <div class="day d_30">00</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row text-center align-items-center border-bottom">
            <div class="col-2">
                <div class="details">
                    <div class="Branch fw-bold">Jaspreet</div>
                </div>
            </div>
            <div class="col-sm-10">
                <div class="row">
                    <div class="col-12">
                        <div class="weeks">
                            <div class="w13">
                                <div class="days">
                                    <span class="day d_1">01</span>
                                    <span class="day d_2">01</span>
                                    <span class="day d_3">01</span>
                                </div>
                            </div>
                            <div class="w14">
                                <div class="days">
                                    <div class="day d_4">01</div>
                                    <div class="day d_5">01</div>
                                    <div class="day d_6">01</div>
                                    <div class="day d_7">01</div>
                                    <div class="day d_8">01</div>
                                    <div class="day d_9">01</div>
                                    <div class="day d_10">01</div>
                                </div>

                            </div>
                            <div class="w15">
                                <div class="days">
                                    <div class="day d_4">00</div>
                                    <div class="day d_5">00</div>
                                    <div class="day d_6">00</div>
                                    <div class="day d_7">00</div>
                                    <div class="day d_8">00</div>
                                    <div class="day d_9">00</div>
                                    <div class="day d_10">00</div>
                                </div>
                            </div>
                            <div class="w16">
                                <div class="days">
                                    <div class="day d_4">00</div>
                                    <div class="day d_5">00</div>
                                    <div class="day d_6">00</div>
                                    <div class="day d_7">00</div>
                                    <div class="day d_8">00</div>
                                    <div class="day d_9">00</div>
                                    <div class="day d_10">00</div>
                                </div>
                            </div>
                            <div class="w17">
                                <div class="days">
                                    <div class="day d_25">00</div>
                                    <div class="day d_26">00</div>
                                    <div class="day d_27">00</div>
                                    <div class="day d_28">00</div>
                                    <div class="day d_29">00</div>
                                    <div class="day d_30">00</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php';?>
</body>
</html>