$(function () {
    var e = new Gantt("#tasks-gantt", [
        {id: "1", name: "AB-31", start: "2022-03-21", end: "2022-04-24", progress: 55},
        {id: "2", name: "AB-31-1", start: "2022-03-21", end: "2022-03-31", progress: 85, dependencies: "1"},
        {id: "3", name: "AB-31-2", start: "2022-04-01", end: "2022-04-23", progress: 80, dependencies: "1"},
        {id: "4", name: "iOS App home page", start: "2022-03-21", end: "2022-03-28", progress: 80},
        {id: "5", name: "ITJP-1", start: "2022-03-23", end: "2022-03-29", progress: 65, dependencies: "4"},
        {id: "6", name: "ITW-1", start: "2022-03-20", end: "2022-03-31", progress: 15},
       {id: "7", name: "TH-21-1", start: "2022-03-28", end: "2022-03-30", progress: 99, dependencies: "6"},
       {id: "8", name: "PM-21-1", start: "2022-03-28", end: "2022-03-31", progress: 35, dependencies: "7"},
       {id: "9", name: "SEO-1", start: "2022-04-01", end: "2022-04-03", progress: 25, dependencies: "8"
    }, {id: "10", name: "OBS-1", start: "2022-04-05", end: "2022-04-07", progress: 60, dependencies: "9"
    }], {
        view_modes: ["Quarter Day", "Half Day", "Day", "Week", "Month"], bar_height: 20, padding: 18, view_mode: "Week",
        custom_popup_html: function (e) {
            e.end;
            var s = 60 <= e.progress ? "bg-success" : 30 <= e.progress && e.progress < 60 ? "bg-primary" : "bg-warning";
            return '<div class="popover fade show bs-popover-right gantt-task-details" role="tooltip"><div class="arrow"></div><div class="popover-body"><h5>' + e.name + '</h5><p class="mb-2">Expected to finish by ${end_date}</p><div class="progress mb-2" style="height: 10px;"><div class="progress-bar ' + s + '" role="progressbar" style="width: ${task.progress}%;" aria-valuenow="${task.progress}" aria-valuemin="0" aria-valuemax="100">${task.progress}%</div></div></div></div>'
        }
    });
    $("#modes-filter :input").on("change", function () {
        e.change_view_mode($(this).val())
    });
    var s = document.getElementById("modes-filter").querySelectorAll(".btn");
    s.forEach(function (e) {
        e.addEventListener("click", function () {
            s.forEach(function (e) {
                e.classList.remove("active")
            }), e.classList.add("active")
        })
    })
});