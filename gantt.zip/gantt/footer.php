
<!-- gantt js-->
<script src="assets/js/vendor/frappe-gantt.min.js"></script>

<!-- demo app -->
<script src="assets/js/pages/demo.js"></script>
<script src="assets/js/pages/demo.project-gantt.js"></script>
<!-- end demo js-->
