<!DOCTYPE html>
<html lang="en">
<?php include 'header.php';?>
<body>
<section id="schedule" class="min-vh-100 bg-white">
    <div class="container">
        <div class="row pt-3">
            <h2>Schedule List</h2>
            <form class="form-horizontal col-9">
                <div class="row mb-2">
                    <label for="date_from" class="col-1 col-form-label">From</label>
                    <div class="col-3">
                        <input type="date" class="form-control form-control-sm" id="date_from" placeholder="date">
                    </div>
                    <label for="date_to" class="col-1 col-form-label">to</label>
                    <div class="col-3">
                        <input type="date" class="form-control form-control-sm" id="date_to" placeholder="date">
                    </div>
                </div>
                <div class="row mb-2">
                    <label for="developer" class="form-label col-1">Developer</label>
                    <div class="col-5">
                        <select id="developer" class="form-select form-select-sm">
                            <option>Choose Developer</option>
                            <option>Amarjeet</option>
                            <option>Jaspreet</option>
                            <option>Bharti</option>
                            <option>Sunil</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
            <div class="alert-success small">
                Developer 1 Schedule from 01/04/2022 to 30/04/2022
            </div>

            <table id="schedule_table" class="table table-bordered mt-2 text-center">
                <thead class="text-center" style="background-color: rgb(0,0,0,.015)">
                    <tr>
                        <th>Date / Hrs<br>April</th>
                        <th>9am-10am</th>
                        <th>10am-11am</th>
                        <th>11am-12pm</th>
                        <th>12pm-1pm</th>
                        <th>Break</th>
                        <th>2pm-3pm</th>
                        <th>3pm-4pm</th>
                        <th>4pm-5pm</th>
                        <th>5pm-6pm</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                <tr class="on" contenteditable="true">
                    <td>1st</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>2nd</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off">
                    <td>3rd</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>4th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>5th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>6th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>7th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>8th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>9th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>10th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>11th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>12th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>13th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="holiday">
                    <td>14th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>15th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>16th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>17th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>18th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>19th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>20th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>21st</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>22nd</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>23rd</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>24th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>25th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>26th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>27th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>28th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="on" contenteditable="true">
                    <td>29th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                <tr class="off" contenteditable="true">
                    <td>30th</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0</td>
                </tr>
                </tbody>
            </table>

        </div>
    </div>
</section>
<?php include 'footer.php';?>
</body>
</html>
