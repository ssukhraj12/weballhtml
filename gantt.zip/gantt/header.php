<head>
    <meta charset="UTF-8">
    <!-- third party css -->
    <link href="assets/css/vendor/frappe-gantt.css" rel="stylesheet" type="text/css" />
    <!-- third party css end -->

    <!-- App css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style" />
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" id="style" />

    <!-- bundle -->
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
    <title>Gantt Chart</title>
</head>
