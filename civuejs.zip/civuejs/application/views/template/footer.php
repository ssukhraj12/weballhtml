</body>
<script src="<?php echo base_url();?>/assets/js/pagination.js"></script>
<script src="<?php echo base_url();?>/assets/js/app.js"></script>

</html>