<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Codeigniter + Vue JS</title>
	<link rel="icon" href="<?php
	echo base_url() ?>assets/img/civue.png">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/bulma.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/animate.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css">

	<script src="<?= base_url() ?>assets/js/vue.min.js"></script>
	<script src="<?= base_url() ?>assets/js/axios.min.js"></script>
	<script src="<?= base_url() ?>assets/js/jquery.min.js"></script>

</head>
<body class="bg-light">
